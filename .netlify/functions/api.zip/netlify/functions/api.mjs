
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// api/lib/vite.ts
var vite_exports = {};
__export(vite_exports, {
  serveStaticFiles: () => serveStaticFiles
});
import { serveStatic } from "@hono/node-server/serve-static";
import fs from "fs";
import path from "path";
function serveStaticFiles(app2) {
  const distPath = path.resolve(import.meta.dirname, "../dist/public");
  app2.use("*", serveStatic({ root: "./dist/public" }));
  app2.notFound((c) => {
    const accept = c.req.header("accept") ?? "";
    if (!accept.includes("text/html")) {
      return c.json({ error: "Not Found" }, 404);
    }
    const indexPath = path.resolve(distPath, "index.html");
    const content = fs.readFileSync(indexPath, "utf-8");
    return c.html(content);
  });
}
var init_vite = __esm({
  "api/lib/vite.ts"() {
  }
});

// netlify/functions/api.ts
import { handle } from "hono/netlify";

// api/boot.ts
import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";

// api/middleware.ts
import { initTRPC } from "@trpc/server";
import superjson from "superjson";
var t = initTRPC.context().create({
  transformer: superjson
});
var createRouter = t.router;
var publicQuery = t.procedure;

// api/routers/product.ts
import { z } from "zod";

// api/lib/supabase.ts
import { createClient } from "@supabase/supabase-js";

// api/lib/env.ts
import "dotenv/config";
function required(name) {
  const value = process.env[name];
  if (!value && process.env.NODE_ENV === "production") {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value ?? "";
}
var env = {
  appId: required("APP_ID"),
  appSecret: required("APP_SECRET"),
  isProduction: process.env.NODE_ENV === "production",
  databaseUrl: required("DATABASE_URL"),
  supabaseUrl: required("SUPABASE_URL"),
  supabaseAnonKey: required("SUPABASE_ANON_KEY"),
  supabaseServiceRoleKey: required("SUPABASE_SERVICE_ROLE_KEY")
};

// api/lib/supabase.ts
if (!globalThis.WebSocket) {
  globalThis.WebSocket = class {
    constructor() {
    }
    close() {
    }
  };
}
var supabase = createClient(
  env.supabaseUrl,
  env.supabaseServiceRoleKey,
  {
    auth: { autoRefreshToken: false, persistSession: false }
  }
);

// api/routers/product.ts
var productRouter = createRouter({
  list: publicQuery.input(
    z.object({
      search: z.string().optional(),
      type: z.string().optional(),
      sortKey: z.string().optional(),
      sortDir: z.enum(["asc", "desc"]).optional()
    }).optional()
  ).query(async ({ input }) => {
    let query = supabase.from("products").select("*");
    if (input?.type && input.type !== "All") {
      query = query.eq("type", input.type);
    }
    if (input?.search) {
      query = query.or(
        `name.ilike.%${input.search}%,sku.ilike.%${input.search}%,supplier.ilike.%${input.search}%`
      );
    }
    const { data, error } = await query;
    if (error) throw new Error(error.message);
    let results = data ?? [];
    if (input?.sortKey) {
      const key = input.sortKey;
      const dir = input.sortDir ?? "asc";
      results.sort((a, b) => {
        const aVal = a[key];
        const bVal = b[key];
        if (typeof aVal === "string" && typeof bVal === "string") {
          return dir === "asc" ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
        }
        if (typeof aVal === "number" && typeof bVal === "number") {
          return dir === "asc" ? aVal - bVal : bVal - aVal;
        }
        return 0;
      });
    }
    return results;
  }),
  getById: publicQuery.input(z.object({ id: z.number() })).query(async ({ input }) => {
    const { data, error } = await supabase.from("products").select("*").eq("id", input.id).single();
    if (error) throw new Error(error.message);
    return data;
  }),
  updateStock: publicQuery.input(z.object({ id: z.number(), stock: z.number() })).mutation(async ({ input }) => {
    const status = input.stock > 20 ? "In Stock" : input.stock > 0 ? "Low Stock" : "Out of Stock";
    const { data, error } = await supabase.from("products").update({ stock: input.stock, status }).eq("id", input.id).select().single();
    if (error) throw new Error(error.message);
    return data;
  }),
  stats: publicQuery.query(async () => {
    const { data, error } = await supabase.from("products").select("stock,status");
    if (error) throw new Error(error.message);
    const items = data ?? [];
    const inStock = items.filter((p) => p.stock > 20).length;
    const lowStock = items.filter(
      (p) => p.stock > 0 && p.stock <= 20
    ).length;
    const outOfStock = items.filter(
      (p) => p.status === "Out of Stock"
    ).length;
    return { inStock, lowStock, outOfStock, total: items.length };
  })
});

// api/routers/order.ts
import { z as z2 } from "zod";
var orderRouter = createRouter({
  list: publicQuery.input(
    z2.object({
      search: z2.string().optional(),
      status: z2.string().optional()
    }).optional()
  ).query(async ({ input }) => {
    let query = supabase.from("orders").select("*");
    if (input?.status) {
      query = query.eq("status", input.status);
    }
    if (input?.search) {
      query = query.or(
        `order_id.ilike.%${input.search}%,customer.ilike.%${input.search}%`
      );
    }
    const { data, error } = await query.order("id", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  }),
  getItems: publicQuery.input(z2.object({ orderId: z2.number() })).query(async ({ input }) => {
    const { data, error } = await supabase.from("order_items").select("product_name").eq("order_id", input.orderId);
    if (error) throw new Error(error.message);
    return (data ?? []).map((i) => i.product_name);
  }),
  updateStatus: publicQuery.input(
    z2.object({
      id: z2.number(),
      status: z2.enum(["Pending", "Processing", "Shipped", "Delivered"])
    })
  ).mutation(async ({ input }) => {
    const { data, error } = await supabase.from("orders").update({ status: input.status }).eq("id", input.id).select().single();
    if (error) throw new Error(error.message);
    return data;
  }),
  stats: publicQuery.query(async () => {
    const { data, error } = await supabase.from("orders").select("status,total");
    if (error) throw new Error(error.message);
    const items = data ?? [];
    const pending = items.filter((o) => o.status === "Pending").length;
    const processing = items.filter(
      (o) => o.status === "Processing"
    ).length;
    const shipped = items.filter((o) => o.status === "Shipped").length;
    const revenue = items.filter((o) => o.status === "Delivered").reduce((s, o) => s + Number(o.total), 0);
    return { pending, processing, shipped, revenue };
  }),
  recent: publicQuery.query(async () => {
    const { data, error } = await supabase.from("orders").select("*").order("id", { ascending: false }).limit(5);
    if (error) throw new Error(error.message);
    return data ?? [];
  })
});

// api/routers/supplier.ts
import { z as z3 } from "zod";
var supplierRouter = createRouter({
  list: publicQuery.input(z3.object({ search: z3.string().optional() }).optional()).query(async ({ input }) => {
    let query = supabase.from("suppliers").select("*");
    if (input?.search) {
      query = query.or(
        `name.ilike.%${input.search}%,code.ilike.%${input.search}%`
      );
    }
    const { data, error } = await query;
    if (error) throw new Error(error.message);
    return data ?? [];
  }),
  stats: publicQuery.query(async () => {
    const { data, error } = await supabase.from("suppliers").select("avg_margin,product_count");
    if (error) throw new Error(error.message);
    const items = data ?? [];
    const avgMargin = items.length > 0 ? Math.round(
      items.reduce((s, i) => s + i.avg_margin, 0) / items.length
    ) : 0;
    const totalProducts = items.reduce(
      (s, i) => s + i.product_count,
      0
    );
    return { avgMargin, totalProducts, count: items.length };
  })
});

// api/routers/analytics.ts
var analyticsRouter = createRouter({
  summary: publicQuery.query(async () => {
    const [productsRes, ordersRes, suppliersRes] = await Promise.all([
      supabase.from("products").select("stock,status,markup"),
      supabase.from("orders").select("status,total,date"),
      supabase.from("suppliers").select("avg_margin,product_count,name")
    ]);
    if (productsRes.error) throw new Error(productsRes.error.message);
    if (ordersRes.error) throw new Error(ordersRes.error.message);
    if (suppliersRes.error) throw new Error(suppliersRes.error.message);
    const products = productsRes.data ?? [];
    const orders = ordersRes.data ?? [];
    const suppliers = suppliersRes.data ?? [];
    const inStock = products.filter((p) => p.stock > 20).length;
    const lowStock = products.filter(
      (p) => p.stock > 0 && p.stock <= 20
    ).length;
    const outOfStock = products.filter(
      (p) => p.status === "Out of Stock"
    ).length;
    const pending = orders.filter((o) => o.status === "Pending").length;
    const processing = orders.filter(
      (o) => o.status === "Processing"
    ).length;
    const revenue = orders.filter((o) => o.status === "Delivered").reduce((s, o) => s + Number(o.total), 0);
    const avgMargin = products.length > 0 ? Math.round(
      products.reduce((s, p) => s + p.markup, 0) / products.length
    ) : 0;
    const supplierMargins = suppliers.map((s) => ({
      name: s.name,
      margin: s.avg_margin
    }));
    const monthlyRevenue = {};
    orders.forEach((o) => {
      if (o.status === "Delivered") {
        const month = o.date.slice(5, 7);
        const monthNames = {
          "01": "Jan",
          "02": "Feb",
          "03": "Mar",
          "04": "Apr",
          "05": "May",
          "06": "Jun",
          "07": "Jul",
          "08": "Aug",
          "09": "Sep",
          "10": "Oct",
          "11": "Nov",
          "12": "Dec"
        };
        const label = monthNames[month] ?? month;
        monthlyRevenue[label] = (monthlyRevenue[label] ?? 0) + Number(o.total);
      }
    });
    return {
      inventory: { inStock, lowStock, outOfStock, total: products.length },
      orders: { pending, processing, revenue },
      avgMargin,
      supplierMargins,
      monthlyRevenue
    };
  })
});

// api/router.ts
var appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  product: productRouter,
  order: orderRouter,
  supplier: supplierRouter,
  analytics: analyticsRouter
});

// api/context.ts
async function createContext(opts) {
  return { req: opts.req, resHeaders: opts.resHeaders };
}

// api/boot.ts
var app = new Hono();
app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));
app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext
  });
});
app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));
var boot_default = app;
if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles: serveStaticFiles2 } = await Promise.resolve().then(() => (init_vite(), vite_exports));
  serveStaticFiles2(app);
  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

// netlify/functions/api.ts
var handler = handle(boot_default);
var api_default = async (req, context) => {
  const url = new URL(req.url);
  if (url.pathname.startsWith("/.netlify/functions/api")) {
    url.pathname = url.pathname.replace("/.netlify/functions/api", "/api");
  }
  const modifiedReq = new Request(url, req);
  return handler(modifiedReq, context);
};
export {
  api_default as default
};
